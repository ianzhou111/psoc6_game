#ifndef __TASK_BUTTON_H__
#define __TASK_BUTTON_H_

#include "splatoon.h"

void init_button_task(void);
extern QueueHandle_t Queue_button;
#endif