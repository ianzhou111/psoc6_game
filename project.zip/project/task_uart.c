#include "task_uart.h"


void task_uart(void *pvParameters);

void init_uart_task(void){
    printf("aaaaaaaaaaa\n");
    Queue_uart = xQueueCreate(1, 20);
    printf("queue suc");
    xTaskCreate(task_uart,
                "uart",
                configMINIMAL_STACK_SIZE,
                NULL,
                6,
                NULL);
}


void task_uart(void *pvParameters)
{
    /* Allocate any local variables used in this task */
    struct Index index;
    printf("%d\n", sizeof(struct Index));
    

    while (1)
    {
        struct Index index;
        index.valid = 0;
        uint8_t rx_msg[2];
        memset(rx_msg, 0, 2);
        if(remote_uart_rx_string_polling(rx_msg)){
            index.valid = 1;
            index.x_arr_index = rx_msg[0];
            printf("%d\n", rx_msg[0]);
            index.y_arr_index = rx_msg[1];
            index.x_scr_index = 24 + index.x_arr_index * 16;
            index.y_scr_index = 72 + index.y_arr_index * 16;
            
        }     
        xQueueSend(Queue_uart, &index, portMAX_DELAY);    
    }
}