#include "task_imu.h"

void task_imu(void *pvParameters);

void init_imu_task(void){
    Queue_Stylus_Position = xQueueCreate(1, sizeof(imu_dir));

    xTaskCreate(task_imu,
                "Joystick",
                configMINIMAL_STACK_SIZE,
                NULL,
                2,
                NULL);
}


void task_imu(void *pvParameters)
{
    /* Allocate any local variables used in this task */
    imu_dir dir = CENTER;

    while (1)
    {
        vTaskDelay(5);
        int16_t x[2];
        lsm6dsm_orientation(x);
       

        /* Check to see what the current position of the
         * joystick is.  If it is not in the center, send a message
         * to the stylus position queue
         */
        if (x[0] > 3500)
        {
            dir = LEFT;
            /* Send the current joystick position to the stylus position queue */
            xQueueSend(Queue_Stylus_Position, &dir, portMAX_DELAY);
        }

        else if(x[0] < -3500)
        {
            dir = RIGHT;
            /* Send the current joystick position to the stylus position queue */
            xQueueSend(Queue_Stylus_Position, &dir, portMAX_DELAY);
        }

        else if(x[1] < -3500)
        {
            dir = UP;
            /* Send the current joystick position to the stylus position queue */
            xQueueSend(Queue_Stylus_Position, &dir, portMAX_DELAY);
        }
        else if(x[1] > 3500)
        {
            dir = DOWN;
            /* Send the current joystick position to the stylus position queue */
            xQueueSend(Queue_Stylus_Position, &dir, portMAX_DELAY);
        }
    }
}