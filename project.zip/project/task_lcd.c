#include "task_lcd.h"
#include "task_imu.h"
#include "task_timer.h"
#include "task_button.h"
#include "task_uart.h"

project_state state = start;
board_status board[grid_x + 1][grid_y + 1];
void task_lcd(void *pvParameters);

void init_lcd_task(void)
{

    xTaskCreate(task_lcd,
                "lcd",
                configMINIMAL_STACK_SIZE * 5,
                NULL,
                3,
                NULL);
}

int who_won(void)
{
    int p1 = 0;
    int p2 = 0;
    for (int i = 0; i < grid_x + 1; i++)
    {
        for (int j = 0; j < grid_y + 1; j++)
        {
            if (board[i][j] == P1_CLAIM)
                p1++;
            if (board[i][j] == P2_CLAIM)
                p2++;
        }
    }
    if (p2 == p1)
    {
        return 0;
    }
    else if (p1 > p2)
    {
        return 1;
    }
    else
    {
        return 2;
    }
}

/**
 * @brief
 * This function will monitor the Stylus Position and Stylus Color queues.
 *
 * If a valid message is received ont he Stylus Position queue, update the coordinates of the cursor
 * and draw a new rectangle at that location.  Wait up to 5mS for a message to arrive on the Position
 * queue.  Be sure to check the return status to see if a valid message was received.
 *
 * If a valid message is received ont he Stylus Color queue, update the color of the cursor
 * and draw a new rectangle at the current location.  Wait up to 5mS for a message to arrive on the Stylus Color
 * queue.  Be sure to check the return status to see if a valid message was received.
 *
 * @param pvParameters
 */
void task_lcd(void *pvParameters)
{
    /* Allocate any local variables used in this task */
    // start indexes

    struct Index player1_index;
    struct Index player2_index;
    if (cur_player.p_num == 1)
    {
        player1_index.x_arr_index = 1;
        player1_index.x_scr_index = 40;
        player1_index.y_arr_index = 5;
        player1_index.y_scr_index = 152;
        player2_index.x_arr_index = 16;
        player2_index.x_scr_index = 280;
        player2_index.y_arr_index = 5;
        player2_index.y_scr_index = 152;
    }

    if (cur_player.p_num == 2)
    {
        player2_index.x_arr_index = 1;
        player2_index.x_scr_index = 40;
        player2_index.y_arr_index = 5;
        player2_index.y_scr_index = 152;
        player1_index.x_arr_index = 16;
        player1_index.x_scr_index = 280;
        player1_index.y_arr_index = 5;
        player1_index.y_scr_index = 152;
    }

    BaseType_t imu_status;
    BaseType_t sw_status;
    BaseType_t timer_status;
    BaseType_t uart_status;

    uint16_t new_color = LCD_COLOR_GREEN;
    int second;
    imu_dir pos = CENTER;
    button_state_t button;

    state = run;
    playtime = 30;
    /* Draw the cursor's initial position */

    if (cur_player.p_num == 1)
    {
        /* Draw the cursor's initial position */
        lcd_draw_image(player1_index.x_scr_index, player1_index.y_scr_index, illWidthPixels, illHeightPixels, illBitmaps, p1_color, BG_COLOR);
        board[player1_index.x_arr_index][player1_index.y_arr_index] = P1_CLAIM;
        lcd_draw_image(player2_index.x_scr_index, player2_index.y_scr_index, illWidthPixels, illHeightPixels, illBitmaps, p2_color, BG_COLOR);
        board[player2_index.x_arr_index][player2_index.y_arr_index] = P2_CLAIM;
    }
    else
    {
        lcd_draw_image(player1_index.x_scr_index, player1_index.y_scr_index, illWidthPixels, illHeightPixels, illBitmaps, p2_color, BG_COLOR);
        board[player1_index.x_arr_index][player1_index.y_arr_index] = P2_CLAIM;
        lcd_draw_image(player2_index.x_scr_index, player2_index.y_scr_index, illWidthPixels, illHeightPixels, illBitmaps, p1_color, BG_COLOR);
        board[player2_index.x_arr_index][player2_index.y_arr_index] = P1_CLAIM;
    }

    while (1)
    {
        /* ADD CODE */
        /* Receive the current position of the joystick from the Stylus Position Queue
         * Timeout after 50mS.
         */
        uart_status = xQueueReceive(Queue_uart, &player2_index, 5);
        imu_status = xQueueReceive(Queue_Stylus_Position, &pos, 5);
        timer_status = xQueueReceive(timer_queue, &second, 5);
        sw_status = xQueueReceive(Queue_button, &button, 5);

        if (state == run)
        {
            printf("in run state\n");
            if (uart_status != NULL && player2_index.valid != 0)
            {

                if (cur_player.p_num == 1)
                {
                    /* Draw the cursor's initial position */
                    lcd_draw_image(player2_index.x_scr_index, player2_index.y_scr_index, illWidthPixels, illHeightPixels, illBitmaps, p2_color, BG_COLOR);
                    board[player2_index.x_arr_index][player2_index.y_arr_index] = P2_CLAIM;
                }
                else
                {
                    lcd_draw_image(player2_index.x_scr_index, player2_index.y_scr_index, illWidthPixels, illHeightPixels, illBitmaps, p1_color, BG_COLOR);
                    board[player2_index.x_arr_index][player2_index.y_arr_index] = P1_CLAIM;
                }
            }

            if (timer_status != NULL && second != -1)
            {
                if (second == 0)
                {
                    hw01_display_alarm(0, second, LCD_COLOR_GREEN);
                    state = idle;
                    continue;
                }
                hw01_display_alarm(0, second, LCD_COLOR_GREEN);
            }

            if (imu_status != NULL && pos != CENTER)
            {
                // slow done
                if (cur_player.p_num == 1)
                {
                    lcd_draw_rectangle(player1_index.x_scr_index - 8, 16, player1_index.y_scr_index - 8, 16, p1_color);
                    lcd_draw_rectangle(player2_index.x_scr_index - 8, 16, player2_index.y_scr_index - 8, 16, p2_color);
                }
                else
                {
                    lcd_draw_rectangle(player1_index.x_scr_index - 8, 16, player1_index.y_scr_index - 8, 16, p2_color);
                    lcd_draw_rectangle(player2_index.x_scr_index - 8, 16, player2_index.y_scr_index - 8, 16, p1_color);
                }
                /* ADD CODE */
                /* Based on the information received, determine where to move the cursor to*/
                /* This implementation does NOT support diagonal movements*/
                switch (pos)
                {
                case LEFT:
                {
                    if (player1_index.x_arr_index > 0)
                    {
                        player1_index.x_arr_index--;
                        player1_index.x_scr_index -= 16;
                    }

                    break;
                }
                case RIGHT:
                {
                    if (player1_index.x_arr_index < grid_x)
                    {
                        player1_index.x_arr_index++;
                        player1_index.x_scr_index += 16;
                    }
                    break;
                }
                case UP:
                {
                    if (player1_index.y_arr_index > 0)
                    {
                        player1_index.y_arr_index--;
                        player1_index.y_scr_index -= 16;
                    }
                    break;
                }
                case DOWN:
                {
                    if (player1_index.y_arr_index < grid_y)
                    {
                        player1_index.y_arr_index++;
                        player1_index.y_scr_index += 16;
                    }
                    break;
                }
                }

                uint8_t tx_msg[2];
                memset(tx_msg, 0, 2);
                tx_msg[0] = player1_index.x_arr_index;
                tx_msg[1] = player1_index.y_arr_index;
                remote_uart_tx_string_polling(tx_msg);
                remote_uart_tx_string_polling("\n");
                
                if (cur_player.p_num == 1)
                {
                    /* Draw the cursor's initial position */
                    lcd_draw_image(player1_index.x_scr_index, player1_index.y_scr_index, illWidthPixels, illHeightPixels, illBitmaps, p1_color, BG_COLOR);
                    board[player1_index.x_arr_index][player1_index.y_arr_index] = P1_CLAIM;
                }
                else
                {
                    lcd_draw_image(player1_index.x_scr_index, player1_index.y_scr_index, illWidthPixels, illHeightPixels, illBitmaps, p2_color, BG_COLOR);
                    board[player1_index.x_arr_index][player1_index.y_arr_index] = P2_CLAIM;
                }
            }
        }
        else
        {
            int winner = who_won();
            printf("yes winner\n");
            if (winner == 0)
            {
                lcd_tie();
            }
            else if (winner == 1)
            {
                lcd_X_wins();
            }
            else
            {
                lcd_O_wins();
            }
            if (sw_status != NULL)
            {
                if (button == BUTTON_SW2_RELEASED)
                {
                    player1_index.x_arr_index = 1;
                    player1_index.x_scr_index = 40;
                    player1_index.y_arr_index = 5;
                    player1_index.y_scr_index = 152;
                    state = run;
                    playtime = 30;
                    lcd_clear_screen(LCD_COLOR_BLACK);
                    lcd_draw_image(player1_index.x_scr_index, player1_index.y_scr_index, illWidthPixels, illHeightPixels, illBitmaps, p1_color, BG_COLOR);
                    draw_boundaries();
                }
            }
        }
        
    }
}
